Placez le master `Compte_rendu_reunion_template_MASTER.docx` dans ce dossier.

Exemple `mappings.json` pour CR (DOCX) :
```
{
	"placeholders": {
		"MEETING_DATE": "date",
		"ATTENDEES": "participants",
		"OBJECT": "object"
	}
}
```

Exemple de `input.json` :
```
{
	"date": "2026-08-16",
	"participants": "Alice, Bob",
	"object": "Atelier cadrage"
}
```

Commande :
```
node scripts/fill_master.js --skill av-compte-rendu-reunion --master .agents/skills/av-compte-rendu-reunion/masters/Compte_rendu_reunion_template_MASTER.docx --data .agents/skills/av-compte-rendu-reunion/input.json --name v1 --out .agents/skills/av-compte-rendu-reunion/out
```

Pour les sections répétées (liste d'actions), le remplacement XML simple ne suffit pas : il faudra un script Node qui duplique des blocs dans le DOCX ou utiliser `docxtemplater`. Dites si vous voulez que j'ajoute ce flux.
